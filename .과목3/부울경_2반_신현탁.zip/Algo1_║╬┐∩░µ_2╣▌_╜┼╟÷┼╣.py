T=int(input())
for t in range(T):
    n=int(input())
    num=[list(map(int,input().split())) for _ in range(n)]
    ans=0
    ans_list=[]
    for i in range(n):
        for j in range(n):
            cnt=0
            for y,x in [[1,1],[-1,-1],[1,-1],[-1,1],[1,0],[-1,0],[0,1],[0,-1]]:# 8방향 탐색작업
                ni=i+y
                nj=x+j
                if 0<=ni<n and 0<=nj<n:# 그래프내 범위일때
                    if num[i][j]>num[ni][nj]:# 주변보다 클경우
                        cnt+=1
            if cnt==8:# cnt가 8개 이상이면 봉우리가 존재한다.
                ans+=1
                ans_list.append(num[i][j])
    if ans==1 or ans == 0:# 봉우리가 1개거나 0개일때
        hi=-1
    else:# 가장 큰 봉우리와 작은 봉우리의 차이
        hi=max(ans_list)-min(ans_list)

    print(f'#{t+1} {hi}')