def dfs(y,x): # dfs로 경로탐색
    if 0<=y<n and 0<=x<n:
        if num[y][x] == 0 and visited[y][x] == 0:# 0일때 그리고 방문한적이 없을경우
            visited[y][x] = 1# 위치정보저장
            a.append(0) # 이동방향저장
            dfs(y,x+1)#다음경로수행
        elif num[y][x] == 1 and visited[y][x] == 0:# 1일때 그리고 방문한적이 없을경우
            visited[y][x] = 1# 위치정보저장
            a.append(1)# 이동방향저장
            dfs(y+1, x)#다음경로수행
        elif num[y][x] == 2 and visited[y][x] == 0:# 2일때 그리고 방문한적이 없을경우
            visited[y][x] = 1# 위치정보저장
            a.append(2)# 이동방향저장
            dfs(y, x-1)#다음경로수행
        elif num[y][x] == 3 and visited[y][x] == 0:# 3일때 그리고 방문한적이 없을경우
            visited[y][x] = 1# 위치정보저장
            a.append(3)# 이동방향저장
            dfs(y-1, x)#다음경로수행
T=int(input())
for t in range(T):
    n=int(input())
    num=[list(map(int,input().split())) for _ in range(n)]
    visited=[[0]*(n) for _ in range(n)] # 위치정보 체크용 그래프생성
    a=[]
    dfs(0,0) # 왼쪽 상단에서 시작
    ans=[]
    for i in a: # 스택을 이용해 중복된 방향제거작업 시행
        if len(ans) == 0: # 스택이 비었을때
            ans.append(i)
        else: # 스택이 비어있지않을때
            if i == ans[-1]:# 스택의 top값과 i가 일치할때 pass
                pass
            else:# 스택의 top값과 i가 일치하지않을때 스택에 i를 추가
                ans.append(i)
    print(f'#{t+1}',*ans)